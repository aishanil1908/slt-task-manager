# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests\frontend.spec.js >> 2. Dashboard Overview >> 3 vertical cards visible (CA, Distribution, Broking)
- Location: tests\frontend.spec.js:156:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.v-ca')
Expected: visible
Error: strict mode violation: locator('.v-ca') resolved to 2 elements:
    1) <div onclick="goMIS('ca')" class="vert-card v-ca">…</div> aka getByText('🏛️CA Practice16GST · ITR ·')
    2) <div class="vert-card v-ca" onclick="misSelectVert('ca')">…</div> aka getByText('🏛️CA Practice2GST · ITR ·')

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('.v-ca')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - complementary [ref=e3]:
    - generic [ref=e5]:
      - generic [ref=e6]: SL
      - generic [ref=e7]:
        - generic [ref=e8]: Second Level Think
        - generic [ref=e9]: Unified Task Platform
    - navigation [ref=e10]:
      - generic [ref=e11]: Main
      - generic [ref=e12] [cursor=pointer]:
        - generic [ref=e13]: 📊
        - generic [ref=e14]: Dashboard
      - generic [ref=e15] [cursor=pointer]:
        - generic [ref=e16]: 🔍
        - generic [ref=e17]: MIS Reports
      - generic [ref=e18]: Tasks
      - generic [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: ⏳
        - generic [ref=e21]: Pending
        - generic [ref=e22]: "72"
      - generic [ref=e23] [cursor=pointer]:
        - generic [ref=e24]: ⚡
        - generic [ref=e25]: In Progress
        - generic [ref=e26]: "27"
      - generic [ref=e27] [cursor=pointer]:
        - generic [ref=e28]: 🔁
        - generic [ref=e29]: Post-Sales F/U
        - generic [ref=e30]: "18"
      - generic [ref=e31] [cursor=pointer]:
        - generic [ref=e32]: ✅
        - generic [ref=e33]: Completed
      - generic [ref=e34]: Admin
      - generic [ref=e35] [cursor=pointer]:
        - generic [ref=e36]: 👥
        - generic [ref=e37]: User Management
      - generic [ref=e38] [cursor=pointer]:
        - generic [ref=e39]: ⚙️
        - generic [ref=e40]: Settings
      - generic [ref=e41] [cursor=pointer]:
        - generic [ref=e42]: 🚪
        - generic [ref=e43]: Logout
    - generic [ref=e44]:
      - generic [ref=e45]: AP
      - generic [ref=e46]:
        - generic [ref=e47]: Shanil Jain
        - generic [ref=e48]: Admin / Partner
  - generic [ref=e49]:
    - generic [ref=e50]:
      - generic [ref=e51]:
        - heading "Dashboard" [level=2] [ref=e52]
        - paragraph [ref=e53]: Welcome back — unified task overview across all verticals
      - button "＋ Create New Task" [ref=e55] [cursor=pointer]
    - generic [ref=e57]:
      - generic [ref=e58]: Task Status Overview — All Verticals
      - generic [ref=e59]:
        - generic [ref=e60] [cursor=pointer]:
          - generic [ref=e61]: ⏳
          - generic [ref=e62]: "72"
          - generic [ref=e63]: Pending
          - generic [ref=e64]: Awaiting action · click to expand
        - generic [ref=e65] [cursor=pointer]:
          - generic [ref=e66]: ⚡
          - generic [ref=e67]: "27"
          - generic [ref=e68]: In Progress
          - generic [ref=e69]: Being worked on · click to expand
        - generic [ref=e70] [cursor=pointer]:
          - generic [ref=e71]: 🔁
          - generic [ref=e72]: "18"
          - generic [ref=e73]: Post-Sales F/U
          - generic [ref=e74]: Awaiting fulfillment confirmation
        - generic [ref=e75] [cursor=pointer]:
          - generic [ref=e76]: ✅
          - generic [ref=e77]: "16"
          - generic [ref=e78]: Completed
          - generic [ref=e79]: Verified & fully closed
      - generic [ref=e80]: Today's Snapshot
      - generic [ref=e81]:
        - generic [ref=e82]:
          - generic [ref=e83]: Created Today
          - generic [ref=e84]: "103"
        - generic [ref=e85]:
          - generic [ref=e86]: Completed Today
          - generic [ref=e87]: "16"
        - generic [ref=e88]:
          - generic [ref=e89]: Overdue Tasks
          - generic [ref=e90]: "0"
        - generic [ref=e91]:
          - generic [ref=e92]: Renewals Due (30d)
          - generic [ref=e93]: "0"
      - generic [ref=e94]: Active Tasks by Vertical
      - generic [ref=e95]:
        - generic [ref=e96] [cursor=pointer]:
          - generic [ref=e97]: 🏛️
          - generic [ref=e98]: CA Practice
          - generic [ref=e99]: "16"
          - generic [ref=e100]: GST · ITR · Audit · Compliance
        - generic [ref=e101] [cursor=pointer]:
          - generic [ref=e102]: 💹
          - generic [ref=e103]: Financial Distribution
          - generic [ref=e104]: "97"
          - generic [ref=e105]: MF · Insurance · PMS · AIF · FD · Banking
        - generic [ref=e106] [cursor=pointer]:
          - generic [ref=e107]: 📈
          - generic [ref=e108]: Broking Services
          - generic [ref=e109]: "4"
          - generic [ref=e110]: Account Opening · Trade Support · KYC
```

# Test source

```ts
  58  | 
  59  |   // Step 5 — Client details
  60  |   await page.locator('#cName').fill('Playwright Test Client');
  61  |   await page.locator('#cMobile').fill('9000000001');
  62  |   await page.locator('#nextBtn').click();
  63  |   await page.waitForTimeout(500);
  64  |   // Now at Step 6
  65  | }
  66  | 
  67  | // ─────────────────────────────────────────────
  68  | // 1. LOGIN
  69  | // ─────────────────────────────────────────────
  70  | test.describe('1. Login', () => {
  71  | 
  72  |   test('Login page loads with correct elements', async ({ page }) => {
  73  |     await page.goto(FRONTEND_URL);
  74  |     await expect(page.locator('#loginPage')).toBeVisible({ timeout: 8000 });
  75  |     await expect(page.locator('#loginUser')).toBeVisible();
  76  |     await expect(page.locator('button.login-btn')).toContainText('Sign In');
  77  |   });
  78  | 
  79  |   test('Valid manager login (shanil) reaches dashboard', async ({ page }) => {
  80  |     await loginAs(page, 'shanil');
  81  |     await expect(page.locator('#appShell')).toBeVisible();
  82  |     await expect(page.locator('#loginPage')).toBeHidden();
  83  |   });
  84  | 
  85  |   test('Valid staff login (priya) reaches dashboard', async ({ page }) => {
  86  |     await loginAs(page, 'priya');
  87  |     await expect(page.locator('#appShell')).toBeVisible();
  88  |   });
  89  | 
  90  |   test('INTRANET FIX: API uses window.location.hostname not hardcoded localhost', async ({ page }) => {
  91  |     // If API was hardcoded to localhost, remote users would get "failed to fetch"
  92  |     // This verifies the fix: const API = `http://${window.location.hostname}:5000/api`
  93  |     await page.goto(FRONTEND_URL);
  94  |     const apiVar = await page.evaluate(() => {
  95  |       // Check the API variable in page scope
  96  |       return typeof API !== 'undefined' ? API : window.API || 'NOT_FOUND';
  97  |     });
  98  |     // API should contain the actual hostname, not literal "localhost" if served from network
  99  |     // At minimum it should be defined and contain port 5000
  100 |     expect(apiVar).toContain('5000');
  101 |     expect(apiVar).toContain('/api');
  102 |   });
  103 | 
  104 |   test('Wrong username does not reach dashboard', async ({ page }) => {
  105 |     await page.goto(FRONTEND_URL);
  106 |     await expect(page.locator('#loginPage')).toBeVisible({ timeout: 8000 });
  107 |     await page.locator('#loginUser').fill('nobody_xyz_999');
  108 |     await page.locator('button.login-btn').click();
  109 |     await page.waitForTimeout(3000);
  110 |     expect(await page.locator('#appShell').isVisible()).toBe(false);
  111 |   });
  112 | 
  113 |   test('Empty username does not proceed', async ({ page }) => {
  114 |     await page.goto(FRONTEND_URL);
  115 |     await expect(page.locator('#loginPage')).toBeVisible({ timeout: 8000 });
  116 |     await page.locator('button.login-btn').click();
  117 |     await page.waitForTimeout(1500);
  118 |     await expect(page.locator('#loginPage')).toBeVisible();
  119 |     await expect(page.locator('#appShell')).toBeHidden();
  120 |   });
  121 | 
  122 | });
  123 | 
  124 | // ─────────────────────────────────────────────
  125 | // 2. DASHBOARD OVERVIEW
  126 | // ─────────────────────────────────────────────
  127 | test.describe('2. Dashboard Overview', () => {
  128 | 
  129 |   test('4 status cards visible with numeric counts', async ({ page }) => {
  130 |     await loginAs(page, 'shanil');
  131 |     const cards = page.locator('.sc');
  132 |     await expect(cards.first()).toBeVisible({ timeout: 5000 });
  133 |     expect(await cards.count()).toBeGreaterThanOrEqual(4);
  134 |   });
  135 | 
  136 |   test('All 4 snapshot tiles show numeric values from API', async ({ page }) => {
  137 |     await loginAs(page, 'shanil');
  138 |     await page.waitForTimeout(3000);
  139 |     for (const id of ['#snap-created', '#snap-done', '#snap-overdue', '#snap-renewals']) {
  140 |       const el = page.locator(id);
  141 |       await expect(el).toBeVisible();
  142 |       const text = await el.textContent();
  143 |       expect(text?.trim(), `${id} must show a number`).toMatch(/^\d+$/);
  144 |     }
  145 |   });
  146 | 
  147 |   test('Renewals Due snap card shows API value (not old hardcoded 12)', async ({ page }) => {
  148 |     await loginAs(page, 'shanil');
  149 |     await page.waitForTimeout(3000);
  150 |     const text = await page.locator('#snap-renewals').textContent();
  151 |     expect(text?.trim()).toMatch(/^\d+$/);
  152 |     // Should definitely not be the old hardcoded "12" if DB has 0 renewals
  153 |     // The fix was adding id="snap-renewals" and wiring to API
  154 |   });
  155 | 
  156 |   test('3 vertical cards visible (CA, Distribution, Broking)', async ({ page }) => {
  157 |     await loginAs(page, 'shanil');
> 158 |     await expect(page.locator('.v-ca')).toBeVisible({ timeout: 5000 });
      |                                         ^ Error: expect(locator).toBeVisible() failed
  159 |     await expect(page.locator('.v-dist')).toBeVisible();
  160 |     await expect(page.locator('.v-broke')).toBeVisible();
  161 |     const pageText = await page.locator('body').textContent();
  162 |     expect(pageText).toContain('CA Practice');
  163 |     expect(pageText).toContain('Financial Distribution');
  164 |     expect(pageText).toContain('Broking Services');
  165 |   });
  166 | 
  167 | });
  168 | 
  169 | // ─────────────────────────────────────────────
  170 | // 3. TASK PANELS (renderPanel bug fix confirmed)
  171 | // ─────────────────────────────────────────────
  172 | test.describe('3. Task Panels', () => {
  173 | 
  174 |   test('Clicking Pending card opens task panel without freezing', async ({ page }) => {
  175 |     await loginAs(page, 'shanil');
  176 |     await page.locator('.s-pend').click();
  177 |     await page.waitForTimeout(2500);
  178 |     await expect(page.locator('#taskPanel')).toBeVisible({ timeout: 5000 });
  179 |     const content = await page.locator('#panelList').textContent();
  180 |     expect(content).not.toContain('Loading tasks');
  181 |   });
  182 | 
  183 |   test('Clicking In Progress card opens panel', async ({ page }) => {
  184 |     await loginAs(page, 'shanil');
  185 |     await page.locator('.s-prog').click();
  186 |     await page.waitForTimeout(2500);
  187 |     await expect(page.locator('#taskPanel')).toBeVisible({ timeout: 5000 });
  188 |     const content = await page.locator('#panelList').textContent();
  189 |     expect(content).not.toContain('Loading tasks');
  190 |   });
  191 | 
  192 |   test('Clicking Post-Sales card opens panel', async ({ page }) => {
  193 |     await loginAs(page, 'shanil');
  194 |     await page.locator('.s-post').click();
  195 |     await page.waitForTimeout(2500);
  196 |     await expect(page.locator('#taskPanel')).toBeVisible({ timeout: 5000 });
  197 |     const content = await page.locator('#panelList').textContent();
  198 |     expect(content).not.toContain('Loading tasks');
  199 |   });
  200 | 
  201 |   test('Clicking Completed card opens panel', async ({ page }) => {
  202 |     await loginAs(page, 'shanil');
  203 |     await page.locator('.s-done').click();
  204 |     await page.waitForTimeout(2500);
  205 |     await expect(page.locator('#taskPanel')).toBeVisible({ timeout: 5000 });
  206 |     const content = await page.locator('#panelList').textContent();
  207 |     expect(content).not.toContain('Loading tasks');
  208 |   });
  209 | 
  210 |   test('Panel close button (✕) closes the panel', async ({ page }) => {
  211 |     await loginAs(page, 'shanil');
  212 |     await page.locator('.s-pend').click();
  213 |     await page.waitForTimeout(2000);
  214 |     await expect(page.locator('#taskPanel')).toBeVisible();
  215 |     await page.locator('.tp-close').click();
  216 |     await page.waitForTimeout(500);
  217 |     await expect(page.locator('#taskPanel')).toBeHidden();
  218 |   });
  219 | 
  220 | });
  221 | 
  222 | // ─────────────────────────────────────────────
  223 | // 4. TASK CREATION WIZARD (6-step waterfall)
  224 | // ─────────────────────────────────────────────
  225 | test.describe('4. Task Creation Wizard', () => {
  226 | 
  227 |   test('Create New Task button opens wizard modal', async ({ page }) => {
  228 |     await loginAs(page, 'shanil');
  229 |     await page.locator('button.btn-create').click();
  230 |     await expect(page.locator('#createOverlay')).toBeVisible({ timeout: 5000 });
  231 |     // Step 1 should be active
  232 |     await expect(page.locator('#cs1')).toBeVisible();
  233 |   });
  234 | 
  235 |   test('Step 1 — vertical options load (CA, Distribution, Broking)', async ({ page }) => {
  236 |     await loginAs(page, 'shanil');
  237 |     await openCreateTask(page);
  238 |     await expect(page.locator('#o-ca')).toBeVisible();
  239 |     await expect(page.locator('#o-dist')).toBeVisible();
  240 |     await expect(page.locator('#o-broke')).toBeVisible();
  241 |   });
  242 | 
  243 |   test('Step 1 → 2 — selecting vertical loads categories from API', async ({ page }) => {
  244 |     await loginAs(page, 'shanil');
  245 |     await openCreateTask(page);
  246 |     await page.locator('#o-dist').click();
  247 |     await page.locator('#nextBtn').click();
  248 |     await page.waitForTimeout(1500);
  249 |     // Category grid should populate from API
  250 |     await expect(page.locator('#cs2')).toBeVisible();
  251 |     const catCount = await page.locator('#catGrid .opt').count();
  252 |     expect(catCount).toBeGreaterThan(0);
  253 |   });
  254 | 
  255 |   test('Step 2 → 3 — selecting category loads natures from API (natureCode fix)', async ({ page }) => {
  256 |     await loginAs(page, 'shanil');
  257 |     await openCreateTask(page);
  258 |     // Step 1
```